import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from '../app/app-routing/app-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OrderRequestComponent } from './order-request/order-request.component';
import {
  FaIconLibrary,
  FontAwesomeModule,
} from '@fortawesome/angular-fontawesome';
import { faCalendarAlt } from '@fortawesome/free-regular-svg-icons';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './guard/auth.guard';
import { ReactiveFormsModule } from '@angular/forms';
import { RoleGuard } from './guard/role.guard';
import { WorkBasketComponent } from './work-basket/work-basket.component';
import { ViewRequestComponent } from './view-request/view-request.component';

@NgModule({
  declarations: [
    AppComponent,
    OrderRequestComponent,
    DashboardComponent,
    LoginComponent,
    WorkBasketComponent,
    ViewRequestComponent,
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgbModule,
    FontAwesomeModule,
  ],
  providers: [AuthGuard, RoleGuard],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(private library: FaIconLibrary) {
    library.addIcons(faCalendarAlt);
  }
}
