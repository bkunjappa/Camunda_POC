import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { forkJoin, Observable } from 'rxjs';
import { CamundaService } from '../service/camunda.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  loginForm = this.fb.group({
    userId: [''],
    password: [''],
  });
  showAlert: boolean = false;

  constructor(private fb:FormBuilder, private router: Router, private camundaService: CamundaService) {}

  ngOnInit(): void {
    localStorage.clear();
  }

  signIn(): void {
    
    this.getUserDetails().subscribe((response) => {
      if (
        response[0].authenticated === true &&
        (response[1].groupId === 'CGIOps' ||
          response[1].groupId === 'CGIVP' ||
          response[1].groupId === 'DCS')
      ) {
        localStorage.setItem('userId', this.loginForm.controls['userId'].value);
        localStorage.setItem('groupId', response[1].groupId);
        this.router.navigate(['/dashboard']);
      } else {
        this.showAlert = true;
      }
    });
  }

  getUserDetails(): Observable<any[]> {
    let userDetails: any = this.camundaService.verifyUser$({
      username: this.loginForm.controls['userId'].value,
      password: this.loginForm.controls['password'].value,
    });

    let groupDetails: any = this.camundaService.getGroup$(this.loginForm.controls['userId'].value);

    return forkJoin([userDetails, groupDetails]);
  }
}
