import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CamundaService } from '../service/camunda.service';

@Component({
  selector: 'app-view-request',
  templateUrl: './view-request.component.html',
  styleUrls: ['./view-request.component.scss'],
})
export class ViewRequestComponent implements OnInit {
  taskId = '';
  showAlert = false;
  alertType = '';
  alertEndMessage = '';
  request: any;

  groupId = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private camundaService: CamundaService
  ) {
    this.groupId = localStorage.getItem('groupId');
  }

  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.taskId = params.taskId;
    });

    this.camundaService
      .getTaskVariables$(this.taskId)
      .subscribe((response) => (this.request = response));
  }

  approve(): void {
    this.camundaService
      .completeRequest(this.taskId, true)
      .subscribe((response: Response) => {
        if (response.status === 204) {
          this.alertType = 'success';
          this.alertEndMessage = 'approved.';

          this.showAlert = true;
        }
      });
  }

  reject(): void {
    this.camundaService
      .completeRequest(this.taskId, false)
      .subscribe((response: Response) => {
        if (response.status === 204) {
          this.alertType = 'warning';
          this.alertEndMessage = 'rejected.';

          this.showAlert = true;
          close();
        }
      });
  }

  sendRequest(sendTo: string): void{
    this.camundaService
      .completeRequest(this.taskId, false)
      .subscribe((response: Response) => {
        if (response.status === 204) {
          this.alertType = 'success';
          this.alertEndMessage = 'sent to '+ sendTo+ '.';

          this.showAlert = true;
          close();
        }
      });

  }

  close(): void {
    this.router.navigate(['/workbasket']);
  }
}
