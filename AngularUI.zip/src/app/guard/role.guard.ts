import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate } from '@angular/router';
import { Router } from '@angular/router';

@Injectable()
export class RoleGuard implements CanActivate {
  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    if (
      localStorage.getItem('userId') &&
      route.data.expectedGroupId.find(
        (x) => x === localStorage.getItem('groupId')
      )
    ) {
      return true;
    }

    this.router.navigate(['/dashboard']);
    return false;
  }
}
