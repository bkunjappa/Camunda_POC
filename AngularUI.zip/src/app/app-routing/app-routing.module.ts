import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { AuthGuard } from '../guard/auth.guard';
import { RoleGuard } from '../guard/role.guard';
import { LoginComponent } from '../login/login.component';
import { OrderRequestComponent } from '../order-request/order-request.component';
import { ViewRequestComponent } from '../view-request/view-request.component';
import { WorkBasketComponent } from '../work-basket/work-basket.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/login' },
  { path: 'login', component: LoginComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'request',
    component: OrderRequestComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      expectedGroupId: ['DCS'],
    },
  },
  {
    path: 'workbasket',
    component: WorkBasketComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      expectedGroupId: ['CGIVP','CGIOps'],
    },
  },
  {
    path: 'viewrequest',
    component: ViewRequestComponent,
    canActivate: [AuthGuard, RoleGuard],
    data: {
      expectedGroupId: ['CGIVP','CGIOps'],
    },
  },
  { path: '**', redirectTo: '/login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
