import { Component, OnInit } from '@angular/core';
import { Observable, from } from 'rxjs';
import { map, switchMap, mergeMap, tap } from 'rxjs/operators';
import { CamundaService } from '../service/camunda.service';

@Component({
  selector: 'app-work-basket',
  templateUrl: './work-basket.component.html',
  styleUrls: ['./work-basket.component.scss'],
})
export class WorkBasketComponent implements OnInit {
  taskItems: any[] = [];

  groupId = localStorage.getItem('groupId');

  task$: Observable<any> = this.camundaService.getTasks$(this.groupId).pipe(
    map((taskResponse: any) => {
      // console.log(taskResponse);
      return taskResponse.map((item: any) => {
        return {
          taskId: item.id,
          createdOn: item.created,
          name: item.name
        };
      });
    })
  );

  taskItems$: any = this.task$.pipe(
    // tap(x=> console.log(x)),
    switchMap((task) =>
      from(task).pipe(
        mergeMap((task: any) =>
          this.camundaService.getTaskVariables$(task.taskId).pipe(
            map((taskVariable: any) => {
              return {
                requestId: taskVariable?.requestId?.value,
                taskId: task.taskId,
                name: task.name,
                createdOn: task.createdOn,      
                projectCode: taskVariable?.projectCode?.value,
                projectName: taskVariable?.projectName?.value,
                positionTitle: taskVariable?.positionTitle?.value,
                positionType: taskVariable?.positionType?.value,
              };
            })
          )
        )
      )
    )
  );

  constructor(private camundaService: CamundaService) {}

  ngOnInit(): void {
    this.taskItems$.subscribe((x) => {
      this.taskItems.push(x);
    });
  }
}
