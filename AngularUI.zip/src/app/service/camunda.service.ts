import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { combineLatest, EMPTY, forkJoin, from, Observable, of } from 'rxjs';
import {
  catchError,
  concatMap,
  map,
  mergeMap,
  switchMap,
  tap,
  toArray,
} from 'rxjs/operators';
import { group } from '@angular/animations';

@Injectable({
  providedIn: 'root',
})
export class CamundaService {
  private apiUrl: string;
  // Http Options
  private httpOptions = {};
  private httpOptionsWithObserve = {};

  constructor(private httpClient: HttpClient) {
    this.apiUrl = 'http://localhost:8080/engine-rest/';
    this.httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'access-control-allow-origin': '*',
      }),
      // observe: 'response',
    };

    this.httpOptionsWithObserve = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'access-control-allow-origin': '*',
      }),
      observe: 'response',
    };
  }

  verifyUser$(requestParams): Observable<any> {
    return this.httpClient
      .post(
        this.apiUrl + `identity/verify`,
        JSON.stringify(requestParams),
        this.httpOptions
      )
      .pipe(
        map((response: any) => ({ authenticated: response.authenticated }))
      );
  }

  getGroup$(userId): Observable<any> {
    const params = new HttpParams().set('userId', userId);

    return this.httpClient
      .get(this.apiUrl + `identity/groups`, {
        params: params,
      })
      .pipe(
        map((response: any) => ({ groupId: response.groups[0].id })),
        catchError((err) => of([]))
      );
  }

  startRequestProcess(request): Observable<any> {
    return this.httpClient.post(
      this.apiUrl +
        `process-definition/TMSProcess_123:1:70b5841d-a861-11eb-9f6d-5e7fe44ad49f/start`,
      request,
      this.httpOptionsWithObserve
    );
  }
  getTasks$(groupId: string): any {
    const params = new HttpParams().set('candidateGroup', groupId);

    return this.httpClient.get(this.apiUrl + `task`, {
      params: params,
    });
  }

  getTaskVariables$(taskId: string): any {
    return this.httpClient.get(this.apiUrl + `task/` + taskId + `/variables`);
  }

  completeRequest(taskId: string, approved: boolean): Observable<any> {
    const request =
      '{"variables": {"vpApproval": {"value": "' +
      (approved ? 'APPROVED' : 'REJECTED') +
      '", "type": "string"}}}';
    console.log(request);
    return this.httpClient.post(
      this.apiUrl + `task/` + taskId + `/complete`,
      request,
      this.httpOptionsWithObserve
    );
  }
}
