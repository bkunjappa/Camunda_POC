import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CamundaService } from '../service/camunda.service';
import * as faker from 'faker';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-order-request',
  templateUrl: './order-request.component.html',
  styleUrls: ['./order-request.component.scss'],
})
export class OrderRequestComponent implements OnInit {
  requestNumber = '';
  showAlert = false;

  requestForm = this.fb.group({
    projectName: [''],
    businessUnit: [''],
    projectCode: [''],
    priority: [''],
    customerName: [''],
    departmentCode: [''],
    requestDate: [''],
    hoursType: [''],
    startDate: [''],
    endDate: [''],
    positionTitle: [''],
    positionType: [''],
    employerTitle: [''],
    jobCategory: [''],
    resourceCount: [''],
    travelRequirements: [''],
    isContractor: [''],
    isHire: [''],
    isMember: [''],
    workLocation: [''],
    centerOfExcellence: [''],
    workLocationAddress: [''],
    salaryRange: [''],
    workLocationCityState: [''],
    payType: [''],
    remoteWork: [''],
    hiringManager: [''],
    hiringManagerEmail: [''],
    hiringManagerPhone: [''],
    pointOfContact: [''],
    pointOfContactEmail: [''],
    pointOfContactPhone: [''],
    sponsorInternationalHire: [''],
    workNotes: [''],
  });
  constructor(
    private fb: FormBuilder,
    private camundaService: CamundaService,
    private router: Router
  ) {}

  ngOnInit(): void {}

  submitRequest(): void {
    let requestJSON = '{"variables": {';
    Object.keys(this.requestForm.controls).forEach((key) => {
      let eachFormProp =
        '"' +
        key +
        '": {"value": "' +
        this.requestForm.controls[key].value +
        '","type": "string"},';

      requestJSON += eachFormProp;
    });

    this.requestNumber = Math.floor(Math.random() * 10000).toString();
    this.requestNumber = 'REQ_' + this.requestNumber.padEnd(4, '0');

    requestJSON +=
      ' "vpApproval": {"value": "", "type": "string" }, "requestId": { "value": "' +
      this.requestNumber +
      '","type": "string"}';

    requestJSON += '},"businessKey": "request1"}';

    this.camundaService
      .startRequestProcess(requestJSON)
      .subscribe((response: Response) => {
        if (response.status === 200) {
          this.showAlert = true;
        }
      });
  }
  close(): void {
    this.router.navigate(['/dashboard']);
  }

  fillData(): void {
    //Math.floor((Math.random() * 10) + 1);
    const businessUnitDummy = ['MID ATL', 'EAST COAST', 'WEST COAST'];
    const priorityDummy = ['Critical', 'High', 'Medium'];
    const positionTitleDummy = [
      'Sr. BPM Developer',
      'Sr. Angular Developer',
      'Sr. Java Developer',
    ];
    const positionTypeDummy = ['New', 'Replacement'];
    const employerTitleDummy = ['Sr. Consultant', 'Tech Lead', 'Sr. Developer'];
    const jobCategoryDummy = [
      'Administration',
      'Agile',
      'Architecture',
      'Business Analysis (functional and technical)',
      'Business Consulting',
      'Cybersecurity',
      'Communications & Investor Relations',
      'Database Administration',
      'Development/Engineering',
      'Digital Customer Experience',
      'Digital Insights (Data/BI)',
      'Digital Transformation Consulting',
      'Director Consulting Services Role',
      'Enterprise Architecture',
      'ERP/CRM/Tools',
      'Finance',
      'Human Resources',
      'Infrastructure/Cloud',
      'Legal Affairs',
      'Management (GTO)',
      'Marketing',
      'Project Management',
      'Project Management - Level 3/4',
      'Senior Management',
      'Service Desk and End User Services',
      'Testing/Quality Assurance',
    ];

    const travelRequirementsDummy = [
      'None',
      '25% or Less',
      '25% - 50%',
      '50% - 75%',
      '75% - 90%',
      '90% - 100%',
    ];

    const workLocationDummy = [
      'Client Site',
      'CGI Office',
      'Remote/Home',
      'Various',
    ];

    const centerOfExcellenceDummy = [
      'No',
      'Yes - Troy, AL',
      'Yes - Lafayette, LA',
      'Yes - Lebanon, VA',
      'Yes - Belton, TX',
      'Yes - Wausau, WI',
      'Yes - Waterville, ME',
    ];

    const remoteWorkDummy = ['No', 'Yes', 'Possibly'];

    this.requestForm.patchValue({
      projectName: 'PNC EDMT CDO',
      businessUnit: businessUnitDummy[Math.floor(Math.random() * 3)],
      projectCode:
        '3' + this.getRandomNumber(100000, 10000).toString().padStart(14, '0'),
      priority: priorityDummy[this.getRandomNumber(2)],
      customerName: faker.name.findName(),
      departmentCode: this.getRandomCode(9999, 1000, 7),
      requestDate: formatDate(new Date(), 'yyyy-MM-dd', 'en'),
      hoursType: Math.random() < 0.5 ? 'Billable' : 'Non Billable',
      startDate: this.getRandomDate(new Date(), new Date('2022-Dec-31')),
      endDate: this.getRandomDate(
        new Date('2022-Dec-31'),
        new Date('2023-Dec-31')
      ),
      positionTitle: positionTitleDummy[this.getRandomNumber(2)],
      positionType: positionTypeDummy[this.getRandomNumber(1)],
      employerTitle: employerTitleDummy[this.getRandomCode(2)],
      jobCategory: jobCategoryDummy[this.getRandomNumber(25)],
      resourceCount: this.getRandomCode(10, 1),
      travelRequirements: travelRequirementsDummy[this.getRandomNumber(4)],
      isContractor: Math.random() < 0.5,
      isHire: Math.random() < 0.5,
      isMember: Math.random() < 0.5,
      workLocation: workLocationDummy[this.getRandomNumber(3)],
      centerOfExcellence: centerOfExcellenceDummy[this.getRandomNumber(6)],
      workLocationAddress: faker.address.streetAddress(),
      salaryRange:
        '60000 - ' +
        (
          Math.round(this.getRandomNumber(100000, 65000) / 1000) * 1000
        ).toString(),
      workLocationCityState:
        faker.address.city() + ', ' + faker.address.stateAbbr(),
      payType:
        Math.random() < 0.5 ? 'Salaried / Exempt' : 'Hourly / Non Exempt',
      remoteWork: remoteWorkDummy[this.getRandomNumber(2)],
      hiringManager: faker.name.findName(),
      hiringManagerEmail: Math.random() < 0.5,
      hiringManagerPhone: Math.random() < 0.5,
      sponsorInternationalHire: Math.random() < 0.5 ? 'Yes' : 'No',
      workNotes: faker.lorem.sentences(3),
    });
  }

  getRandomNumber(max: number, min: number = 0): number {
    return Math.floor(Math.random() * (max + 1 - min)) + min;
  }

  getRandomCode(max: number, min: number = 0, padding: number = 0): string {
    return this.getRandomNumber(max, min).toString().padStart(padding, '0');
  }

  getRandomDate(start: Date, end: Date): string {
    return formatDate(
      new Date(
        start.getTime() + Math.random() * (end.getTime() - start.getTime())
      ),
      'yyyy-MM-dd',
      'en'
    );
  }
}
