import { Component, DoCheck } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements DoCheck {
  title = 'CGITalentManage';
  userId = '';

  constructor(public router: Router) {}

  ngDoCheck(): void {
    this.userId = localStorage.getItem('userId');
  }
}
